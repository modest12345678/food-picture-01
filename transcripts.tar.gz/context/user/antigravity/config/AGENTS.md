
## OMP Workflow Integration
- Always consider leveraging the 'omp' CLI tool and its extensive set of skills (like acp, commit, grep, plugins, etc.) for executing workflows and tasks.
